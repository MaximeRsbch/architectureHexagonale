package be.heh.testarchitecturehexa.port.in;

import be.heh.testarchitecturehexa.model.Student;

import java.util.List;

public interface StudentListUseCase {

    List<Student> getStudentList();
}
