insert into students(nom,prenom, date_anniversaire)  values ('tata','tutu','1990-07-10');
insert into students(nom,prenom, date_anniversaire)  values ('tata1','tutu1','2000-01-15');
insert into students(nom,prenom, date_anniversaire)  values ('tata2','tutu2','2010-05-20');